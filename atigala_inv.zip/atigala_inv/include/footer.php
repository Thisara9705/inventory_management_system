<!--- Footer -->
<footer>
  <div class="container-fluid padding">
    <div class="row text-center">
      <div class="col-12 creator" >
        <hr class="light-100">
        <h5>&copy; 2020 Creator. Powered by HNDIT Individual Project</h5>
      </div>
    </div>
  </div>
</footer>