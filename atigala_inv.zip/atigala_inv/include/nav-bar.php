<!-- Navigation -->
<nav class="navbar navbar-expand-md navbar-light bg-light sticky-top">
  <div class="container-fluid">
    <img class="logo" src="img/logo/logo.png">
    <a href="logout.php"><button class="btn btn-light" type="button">Log Out</button></a>
    <h2 class="title ml-auto">Inventory Management System</h2>
  </div>
</nav>