<?php
session_start();

define("HOST","localhost");
define("USER","root");
define("PASS","");
define("DB","atigala_invdb");

define("DOMAIN","http://localhost/atigala_inv");

?>